<?php return array('dependencies' => array(), 'version' => '078611e16431f0d2ea86');
