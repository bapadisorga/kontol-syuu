<?php return array('dependencies' => array('bp-block-data', 'react', 'wp-block-editor', 'wp-blocks', 'wp-components', 'wp-i18n', 'wp-server-side-render'), 'version' => '8c8f754d871f42afe84b');
