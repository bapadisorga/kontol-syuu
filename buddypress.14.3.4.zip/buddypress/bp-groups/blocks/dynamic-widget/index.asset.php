<?php return array('dependencies' => array('bp-dynamic-widget-block', 'wp-escape-html', 'wp-i18n'), 'version' => '23f62f52c3c46861b3f4');
